## Command o build the whl file of the iagentops-sdk use the below command
``` python setup.py sdist bdist_wheel ```

## Command to install the whl file as package in client-side
``` pip install iagentops-0.1.0-py3-none-any.whl ```

## Command to see if the `iagentops` package is installed or not in client-side
``` pip show -f iagentops ```


