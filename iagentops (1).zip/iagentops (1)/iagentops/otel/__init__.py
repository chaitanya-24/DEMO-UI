# Package initializer for iagentops.otel
# Ensure otel is a proper package and is included in distribution.

__all__ = ["metrics", "tracing"]