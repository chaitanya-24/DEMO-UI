import time
import importlib.util
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from wrapt import wrap_function_wrapper
from iagentops.otel import metrics, tracing
from iagentops.semconv import SemanticConvention as SC
from iagentops import helpers
import json
import traceback

WRAPPED_METHODS = [
    # LLM synchronous inference
    {"package": "langchain.llms.base", "object": "BaseLLM.predict", "provider_attr": "client_name", "operation": "inference"},
    {"package": "langchain.llms.base", "object": "BaseLLM.generate", "provider_attr": "client_name", "operation": "inference"},
    {"package": "langchain_core.language_models.chat_models", "object": "BaseChatModel.invoke", "provider_attr": "client_name", "operation": "inference"},
    {"package": "langchain_core.language_models.chat_models", "object": "BaseChatModel.generate", "provider_attr": "client_name", "operation": "inference"},

    # Chains / workflows
    {"package": "langchain.chains.base", "object": "BaseChain.run", "provider_attr": None, "operation": "workflow"},

    # Agents and agent executors
    {"package": "langchain.agents.agent", "object": "Agent.run", "provider_attr": None, "operation": "invoke_agent"},
    {"package": "langchain.agents.agent", "object": "AgentExecutor.run", "provider_attr": None, "operation": "invoke_agent"},

    # Tools
    {"package": "langchain.tools.base", "object": "BaseTool.run", "provider_attr": None, "operation": "tool"},

    # Embeddings
    {"package": "langchain.embeddings.base", "object": "Embeddings.embed", "provider_attr": None, "operation": "embedding"},
    {"package": "langchain.embeddings.base", "object": "Embeddings.embed_documents", "provider_attr": None, "operation": "embedding"},
]

class LangChainInstrumentor:
    def instrument(self, service_name="iagentops", environment="development", sdk_version="0.1.0", agent_id=None, server_address=None, server_port=None, collector_endpoint=None, use_console_exporter=True, exporter_protocol="http", **kwargs):
        self.tracer = tracing.setup_tracer(
            service_name=service_name, 
            environment=environment, 
            sdk_version=sdk_version,
            agent_id=agent_id,
            server_address=server_address,
            server_port=server_port,
            collector_endpoint=collector_endpoint,
            use_console_exporter=use_console_exporter,
            exporter_protocol=exporter_protocol
        )
        # Gracefully skip if langchain isn't installed
        if importlib.util.find_spec("langchain") is None:
            return
        
        for m in WRAPPED_METHODS:
            try:
                # Only attempt to wrap if the specific package path exists in this LangChain version
                if importlib.util.find_spec(m["package"]) is None:
                    continue
                wrap_function_wrapper(
                    m["package"], m["object"], self._wrap(m.get("provider_attr"), m.get("operation"))
                )
            except Exception:
                # Skip if target path doesn't exist or wrapping fails
                continue

    def _wrap(self, provider_attr, operation=None):
        def wrapper(wrapped, instance, args, kwargs):
            # Detect provider if available
            provider = self._detect_provider(instance, provider_attr) if provider_attr else "unknown"
            model = getattr(instance, "model_name", None) or getattr(instance, "model", None)

            # Name the span based on class and method for good observability
            class_name = instance.__class__.__name__ if instance is not None else "Unknown"
            method_name = getattr(wrapped, "__name__", "call")
            span_name = f"{class_name}.{method_name}"

            # Map operation to semantic convention values
            op_type = SC.GEN_AI_OPERATION_TYPE_CHAT
            if operation == "workflow":
                op_type = SC.GEN_AI_OPERATION_TYPE_WORKFLOW
            elif operation == "embedding":
                op_type = SC.GEN_AI_OPERATION_TYPE_EMBEDDING
            elif operation == "invoke_agent":
                op_type = SC.GEN_AI_OPERATION_TYPE_WORKFLOW

            with self.tracer.start_as_current_span(span_name) as span:
                max_tokens = helpers._find_max_tokens(instance, kwargs)
                temperature = helpers.temperature(instance, kwargs)
                top_p = helpers.top_p(instance, kwargs)
                model_version=helpers.find_model_version(instance,kwargs)

                # Common attributes
                span.set_attribute(SC.GEN_AI_OPERATION, op_type)
                # span.set_attribute(SC.GEN_AI_SYSTEM, provider)
                # Provider name (explicit field) for clarity in attributes
                # span.set_attribute("gen_ai.provider.name", provider)
                # Mark which agent framework produced this span
                span.set_attribute(SC.AGENT_FRAMEWORK, "langchain")
                span.set_attribute(SC.GEN_AI_REQUEST_MODEL, model or "unknown")
                span.set_attribute(SC.GEN_AI_LLM, model or "unknown")
                span.set_attribute(SC.GEN_AI_LLM_PROVIDER, provider or "unknown")
                if model_version is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_MODEL_VERSION,model_version)
                # span.set_attribute(SC.GEN_AI_REQUEST_MODEL, model or "unknown")
                if temperature is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_TEMPERATURE,temperature)
                if top_p is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_TOP_P,top_p)
                if max_tokens is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_MAX_TOKENS, max_tokens)

                # If this is a tool call, add tool metadata if present on instance
                if operation == "tool":
                    tool_name = getattr(instance, "name", None) or getattr(instance, "tool_name", None)
                    span.set_attribute(SC.GEN_AI_TOOL_NAME, tool_name or "unknown")
                    span.set_attribute(SC.GEN_AI_TOOL_TYPE, getattr(instance, "tool_type", "unknown"))
                    span.set_attribute(SC.GEN_AI_TOOL_DESCRIPTION, getattr(instance, "description", ""))

                span.set_attribute(SC.GEN_AI_CONVERSATION_ID, kwargs.get("conversation_id", "unknown"))
                span.set_attribute(SC.GEN_AI_DATA_SOURCE_ID, kwargs.get("data_source_id", "unknown"))

                start = time.perf_counter()
                try:
                    result = wrapped(*args, **kwargs)
                    end = time.perf_counter()

                    latency_s = end - start
                    latency_ms = latency_s * 1000

                    input_tokens, output_tokens = helpers.extract_tokens(args, result, model)
                    # Input/output messages serialization where possible
                    try:
                        if args and len(args) >= 1:
                            inp = args[0]
                            span.set_attribute(SC.GEN_AI_INPUT_MESSAGES, json.dumps(inp))
                        else:
                            span.set_attribute(SC.GEN_AI_INPUT_MESSAGES, "")
                    except Exception:
                        span.set_attribute(SC.GEN_AI_INPUT_MESSAGES, str(args if args else ""))

                    try:
                        span.set_attribute(SC.GEN_AI_OUTPUT_MESSAGES, json.dumps(result))
                    except Exception:
                        span.set_attribute(SC.GEN_AI_OUTPUT_MESSAGES, str(result))
                    span.set_attribute(SC.GEN_AI_RESPONSE_MODEL, model or "unknown")
                    span.set_attribute(SC.GEN_AI_USAGE_INPUT_TOKENS, input_tokens)
                    span.set_attribute(SC.GEN_AI_USAGE_OUTPUT_TOKENS, output_tokens)
                    span.set_attribute(SC.GEN_AI_CLIENT_OPERATION_DURATION, latency_s)

                    metrics.emit_metrics(latency_ms, provider, input_tokens, output_tokens, model)
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    # Record exception as event with rich attributes
                    tb = traceback.format_exc()
                    span.add_event("exception", {
                        "exception.type": type(e).__name__,
                        "exception.message": str(e),
                        "exception.stacktrace": tb,
                        "exception.escaped": "False",
                    })
                    span.record_exception(e)
                    raise

        return wrapper

    def _detect_provider(self, instance, provider_attr):
        """Detect provider from LLM instance."""
        # Try explicit attribute first
        provider = getattr(instance, provider_attr, None)
        if provider and provider != "unknown":
            return provider.lower()
        
        # Detect from class name
        class_name = instance.__class__.__name__.lower()
        if "openai" in class_name or "chatgpt" in class_name:
            return "openai"
        elif "anthropic" in class_name or "claude" in class_name:
            return "anthropic"
        elif "google" in class_name or "gemini" in class_name or "vertex" in class_name:
            return "google"
        elif "azure" in class_name:
            return "azure"
        elif "cohere" in class_name:
            return "cohere"
        
        # Check module path
        module = instance.__class__.__module__
        if "openai" in module:
            return "openai"
        elif "anthropic" in module:
            return "anthropic"
        elif "google" in module:
            return "google"
        
        return "unknown"
