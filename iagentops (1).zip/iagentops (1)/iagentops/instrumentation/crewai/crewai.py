import time
import importlib.util
from opentelemetry.trace import Status, StatusCode
from wrapt import wrap_function_wrapper
from iagentops.otel import metrics, tracing
from iagentops.semconv import SemanticConvention as SC
from iagentops import helpers
import json
import traceback

WRAPPED_METHODS = [
    # Crew-level workflow execution (Main entry point)
    {"package": "crewai.crew", "object": "Crew.kickoff", "provider_attr": None, "operation": "workflow"},
    {"package": "crewai.crew", "object": "Crew.kickoff_for_each", "provider_attr": None, "operation": "workflow"},
    
    # Agent execution (Decision making and tool usage loop)
    {"package": "crewai.agent", "object": "Agent.run", "provider_attr": None, "operation": "invoke_agent"},
    
    # Task execution (Execution of specific instructions/logic)
    {"package": "crewai.task", "object": "Task.execute", "provider_attr": None, "operation": "task"},

    # Tool execution (If you need explicit tracing of individual tool runs)
    {"package": "crewai.tools.base", "object": "BaseTool.run", "provider_attr": None, "operation": "tool"},
]


def get_llm_attr(llm, key, default=None):
    # Try direct attribute
    val = getattr(llm, key, None)
    if val:
        return val
    # Try __dict__
    if hasattr(llm, "__dict__"):
        val = llm.__dict__.get(key)
        if val:
            return val
    # Try Pydantic v2 model_dump
    if hasattr(llm, "model_dump"):
        val = llm.model_dump().get(key)
        if val:
            return val
    # Try Pydantic v1 dict()
    if hasattr(llm, "dict"):
        val = llm.dict().get(key)
        if val:
            return val
    return default



def _extract_model_and_provider(instance):
    checked = set()
    def _find(obj):
        if not obj or id(obj) in checked:
            return None, None
        checked.add(id(obj))
        model = None
        provider = None
        for mk in ("model_name", "model", "_model_name"):
            val = getattr(obj, mk, None)
            if val:
                model = val
        for pk in ("provider", "client_name", "api_type"):
            val = getattr(obj, pk, None)
            if val:
                provider = val
        # Recurse
        for sub in ("llm", "agent", "parent", "crew"):
            sub_obj = getattr(obj, sub, None)
            if sub_obj:
                m, p = _find(sub_obj)
                if m and not model:
                    model = m
                if p and not provider:
                    provider = p
        return model, provider
    m, p = _find(instance)
    return str(m) if m else "unknown", str(p) if p else "unknown"


def extract_prompt(args, kwargs, instance):
    # Try input message from args/kwargs
    prompt = helpers.extract_input_message(args, kwargs)
    # Try instance.description or .prompt if not found
    if not prompt:
        prompt = getattr(instance, "description", None) or getattr(instance, "prompt", None)
    return prompt


class CrewAIInstrumentor:
    """Instrumentor for CrewAI sync LLM calls."""

    def instrument(self, service_name="iagentops", environment="development", sdk_version="0.1.0", agent_id=None, server_address=None, server_port=None, collector_endpoint=None, use_console_exporter=True, exporter_protocol="http", **kwargs):
        self.tracer = tracing.setup_tracer(
            service_name=service_name,
            environment=environment,
            sdk_version=sdk_version,
            agent_id=agent_id,
            server_address=server_address,
            server_port=server_port,
            collector_endpoint=collector_endpoint,
            use_console_exporter=use_console_exporter,
            exporter_protocol=exporter_protocol
        )
        if importlib.util.find_spec("crewai") is None:
            return
        for m in WRAPPED_METHODS:
            if importlib.util.find_spec(m["package"]) is None:
                continue
            wrap_function_wrapper(
                m["package"], m["object"], self._wrap(m.get("provider_attr"), m.get("operation"))
            )


    def _wrap(self, provider_attr, operation=None):
        def wrapper(wrapped, instance, args, kwargs):
            # --- Robust model/provider extraction ---
            model, provider = _extract_model_and_provider(instance)

            class_name = instance.__class__.__name__ if instance is not None else "Unknown"
            method_name = getattr(wrapped, "__name__", "call")
            span_name = f"{class_name}.{method_name}"

            from iagentops.semconv import SemanticConvention as SC
            op_type = SC.GEN_AI_OPERATION_TYPE_WORKFLOW if operation in (None, "workflow") else SC.GEN_AI_OPERATION_TYPE_CHAT
            if operation == "embedding":
                op_type = SC.GEN_AI_OPERATION_TYPE_EMBEDDING

            with self.tracer.start_as_current_span(span_name) as span:
                # --- Explicit service/environment attributes ---
                span.set_attribute("service.name", getattr(self, "service_name", "iagentops"))
                span.set_attribute("deployment.environment", getattr(self, "environment", "development"))

                # --- Legacy/compat attributes (optional, keep if needed) ---
                max_tokens = helpers._find_max_tokens(instance, kwargs)
                temperature = helpers.temperature(instance, kwargs)
                top_p = helpers.top_p(instance, kwargs)
                model_version = helpers.find_model_version(instance, kwargs)

                span.set_attribute(SC.GEN_AI_OPERATION, op_type)
                span.set_attribute(SC.AGENT_FRAMEWORK, "crewai")
                span.set_attribute("gen_ai.request.model", model)
                span.set_attribute("gen_ai.model.name", model)
                span.set_attribute("gen_ai.model.provider", provider)
                span.set_attribute(SC.GEN_AI_REQUEST_MODEL, model)
                span.set_attribute(SC.GEN_AI_LLM, model)
                span.set_attribute(SC.GEN_AI_LLM_PROVIDER, provider)
                if model_version is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_MODEL_VERSION, model_version)
                if temperature is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_TEMPERATURE, temperature)
                if top_p is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_TOP_P, top_p)
                if max_tokens is not None:
                    span.set_attribute(SC.GEN_AI_REQUEST_MAX_TOKENS, max_tokens)

                # --- Cast IDs to str before setting ---
                agent_id = getattr(instance, "id", None) or getattr(instance, "agent_id", None)
                if agent_id is not None and not isinstance(agent_id, (str, int, float, bool, bytes)):
                    agent_id = str(agent_id)
                span.set_attribute(SC.GEN_AI_AGENT_ID, agent_id or "unknown")

                if operation == "tool":
                    tool_name = getattr(instance, "name", None) or getattr(instance, "tool_name", None)
                    tool_id = getattr(instance, "id", None) or getattr(instance, "tool_id", None)
                    if tool_id is not None and not isinstance(tool_id, (str, int, float, bool, bytes)):
                        tool_id = str(tool_id)
                    span.set_attribute(SC.GEN_AI_TOOL_ID, tool_id or "unknown")
                    span.set_attribute(SC.GEN_AI_TOOL_NAME, tool_name or "unknown")
                    span.set_attribute(SC.GEN_AI_TOOL_TYPE, getattr(instance, "tool_type", "unknown"))
                    span.set_attribute(SC.GEN_AI_TOOL_DESCRIPTION, getattr(instance, "description", ""))

                # Other IDs (e.g., task_id)
                if hasattr(instance, "task_id"):
                    task_id = getattr(instance, "task_id")
                    if task_id is not None and not isinstance(task_id, (str, int, float, bool, bytes)):
                        task_id = str(task_id)
                    span.set_attribute(SC.GEN_AI_TASK_ID, task_id)

                span.set_attribute(SC.GEN_AI_CONVERSATION_ID, kwargs.get("conversation_id", "unknown"))
                span.set_attribute(SC.GEN_AI_DATA_SOURCE_ID, kwargs.get("data_source_id", "unknown"))

                import time
                start = time.perf_counter()
                try:
                    result = wrapped(*args, **kwargs)
                    end = time.perf_counter()
                    latency_s = end - start

                    # --- Prompt/Completion event emission ---
                    prompt = extract_prompt(args, kwargs, instance)
                    now = int(time.time() * 1e9)
                    if prompt:
                        span.add_event("gen_ai.content.prompt", {"gen_ai.prompt": prompt}, timestamp=now)
                    if result:
                        completion = None
                        if isinstance(result, dict) and "completion" in result:
                            completion = result["completion"]
                        elif hasattr(result, "completion"):
                            completion = result.completion
                        elif isinstance(result, str):
                            completion = result
                        else:
                            completion = str(result)
                        span.add_event("gen_ai.content.completion", {"gen_ai.completion": completion}, timestamp=now)

                    # --- Openlit agent telemetry ---
                    import iagentops.helpers as helpers_mod
                    helpers_mod.emit_agent_telemetry(
                        span=span,
                        instance=instance,
                        args=args,
                        kwargs=kwargs,
                        result=result,
                        model=model,
                        duration=latency_s,
                    )

                    # --- Legacy metrics/attributes (optional) ---
                    from iagentops.otel import metrics
                    input_msg = helpers.extract_input_message(args, kwargs)
                    try:
                        span.set_attribute(SC.GEN_AI_INPUT_MESSAGES, json.dumps(input_msg))
                    except Exception:
                        span.set_attribute(SC.GEN_AI_INPUT_MESSAGES, str(input_msg))
                    try:
                        span.set_attribute(SC.GEN_AI_OUTPUT_MESSAGES, json.dumps(result))
                    except Exception:
                        span.set_attribute(SC.GEN_AI_OUTPUT_MESSAGES, str(result))
                    span.set_attribute("gen_ai.response.model", model)
                    span.set_attribute(SC.GEN_AI_RESPONSE_MODEL, model)

                    # --- Token tracking only ---
                    input_tokens = helpers._safe_encode(input_msg, model)
                    output_tokens = helpers._safe_encode(str(result), model)
                    span.set_attribute(SC.GEN_AI_USAGE_INPUT_TOKENS, input_tokens)
                    span.set_attribute(SC.GEN_AI_USAGE_OUTPUT_TOKENS, output_tokens)
                    span.set_attribute(SC.GEN_AI_CLIENT_OPERATION_DURATION, latency_s)

                    metrics.emit_metrics(latency_s * 1000, provider, input_tokens, output_tokens, model)
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    tb = traceback.format_exc()
                    span.add_event("exception", {
                        "exception.type": type(e).__name__,
                        "exception.message": str(e),
                        "exception.stacktrace": tb,
                        "exception.escaped": "False",
                    })
                    span.record_exception(e)
                    raise

        return wrapper




    def _detect_provider(self, instance, provider_attr):
        provider = getattr(instance, provider_attr, None)
        if provider and provider != "unknown":
            return provider.lower()
        class_name = instance.__class__.__name__.lower()
        if "openai" in class_name:
            return "openai"
        elif "anthropic" in class_name:
            return "anthropic"
        elif "google" in class_name:
            return "google"
        
        module = instance.__class__.__module__
        if "openai" in module:
            return "openai"
        elif "anthropic" in module:
            return "anthropic"
        elif "google" in module:
            return "google"
        return "unknown"
